import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BIZNOBIX — One Platform. Smarter Business.",
  description: "AI-powered business operations workspace."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
