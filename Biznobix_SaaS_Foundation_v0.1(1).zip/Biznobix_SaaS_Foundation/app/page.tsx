"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Activity, ArrowUpRight, Bot, BriefcaseBusiness, Check, CheckCircle2,
  ChevronDown, CircleHelp, ClipboardList, Command, LayoutDashboard,
  LogOut, Mail, Menu, Plus, Search, Settings, Sparkles, Target,
  TrendingUp, Users, X
} from "lucide-react";
import { createClient } from "@/lib/supabase";

type Lead = { id: string; name: string; company: string | null; email: string | null; status: string; created_at?: string };
type Task = { id: string; title: string; completed: boolean; created_at?: string };

const navigation = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "AI Copilot", icon: Bot, soon: true },
  { label: "CRM & Leads", icon: Users },
  { label: "Sales Pipeline", icon: Target, soon: true },
  { label: "Marketing", icon: Mail, soon: true },
  { label: "Tasks", icon: ClipboardList },
  { label: "Analytics", icon: Activity, soon: true }
];

export default function Home() {
  const supabase = useMemo(() => createClient(), []);
  const [userEmail, setUserEmail] = useState("");
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [leads, setLeads] = useState<Lead[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [leadName, setLeadName] = useState("");
  const [leadCompany, setLeadCompany] = useState("");
  const [taskTitle, setTaskTitle] = useState("");
  const [search, setSearch] = useState("");
  const [active, setActive] = useState("Overview");
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    supabase.auth.getSession().then(({ data }) => {
      if (alive) setUserEmail(data.session?.user.email ?? "");
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserEmail(session?.user.email ?? "");
    });
    return () => { alive = false; listener.subscription.unsubscribe(); };
  }, [supabase]);

  useEffect(() => {
    if (!supabase || !userEmail) return;
    refreshData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [supabase, userEmail]);

  async function refreshData() {
    if (!supabase) return;
    const [{ data: leadData }, { data: taskData }] = await Promise.all([
      supabase.from("leads").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("tasks").select("*").order("created_at", { ascending: false }).limit(100)
    ]);
    setLeads((leadData ?? []) as Lead[]);
    setTasks((taskData ?? []) as Task[]);
  }

  async function authenticate(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!supabase) { setMessage("Connect Supabase first using the setup guide in README.md."); return; }
    setAuthBusy(true); setMessage("");
    const result = authMode === "signup"
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password });
    setAuthBusy(false);
    if (result.error) setMessage(result.error.message);
    else if (authMode === "signup") setMessage("Account created. Check your email if confirmation is enabled.");
  }

  async function addLead(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!supabase || !leadName.trim()) return;
    const { error } = await supabase.from("leads").insert({ name: leadName.trim(), company: leadCompany.trim() || null, status: "New" });
    if (error) setMessage(error.message);
    else { setLeadName(""); setLeadCompany(""); await refreshData(); }
  }

  async function addTask(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!supabase || !taskTitle.trim()) return;
    const { error } = await supabase.from("tasks").insert({ title: taskTitle.trim(), completed: false });
    if (error) setMessage(error.message);
    else { setTaskTitle(""); await refreshData(); }
  }

  async function toggleTask(task: Task) {
    if (!supabase) return;
    await supabase.from("tasks").update({ completed: !task.completed }).eq("id", task.id);
    await refreshData();
  }

  async function deleteLead(id: string) {
    if (!supabase) return;
    await supabase.from("leads").delete().eq("id", id);
    await refreshData();
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setUserEmail("");
  }

  const filteredLeads = leads.filter(l => `${l.name} ${l.company ?? ""} ${l.email ?? ""}`.toLowerCase().includes(search.toLowerCase()));
  const completed = tasks.filter(t => t.completed).length;

  if (!userEmail) return (
    <main className="auth-shell">
      <section className="auth-card">
        <div className="brand-mark"><Command size={22} /></div>
        <div className="eyebrow">THE BUSINESS OPERATING PLATFORM</div>
        <h1>Make your business<br /><span>work smarter.</span></h1>
        <p className="muted">One connected workspace for your team, customers and growth.</p>
        {!supabase && <div className="notice">Supabase is not connected yet. Follow the setup steps in README.md to activate accounts and cloud data.</div>}
        <form onSubmit={authenticate} className="auth-form">
          <label>Email address<input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" required /></label>
          <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 6 characters" minLength={6} required /></label>
          <button className="primary-btn" disabled={authBusy}>{authBusy ? "Please wait…" : authMode === "signin" ? "Sign in to BIZNOBIX" : "Create your workspace"} <ArrowUpRight size={17} /></button>
        </form>
        <p className="auth-switch">{authMode === "signin" ? "New to BIZNOBIX?" : "Already have an account?"} <button onClick={() => { setAuthMode(authMode === "signin" ? "signup" : "signin"); setMessage(""); }}>{authMode === "signin" ? "Create account" : "Sign in"}</button></p>
        {message && <p className="message">{message}</p>}
        <div className="auth-foot">BIZNOBIX · One Platform. Smarter Business.</div>
      </section>
    </main>
  );

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="brand"><div className="brand-mark"><Command size={20} /></div><span>BIZNO<span className="brand-accent">BIX</span></span><button className="mobile-close" onClick={() => setMobileOpen(false)}><X size={18} /></button></div>
        <div className="workspace"><div className="workspace-avatar">B</div><div><strong>My Workspace</strong><small>Free workspace</small></div><ChevronDown size={15} /></div>
        <div className="nav-label">WORKSPACE</div>
        <nav>{navigation.map(item => <button key={item.label} className={`nav-item ${active === item.label ? "selected" : ""}`} onClick={() => { setActive(item.label); setMobileOpen(false); }}><item.icon size={18} /><span>{item.label}</span>{item.soon && <small>SOON</small>}</button>)}</nav>
        <div className="sidebar-bottom"><button className="nav-item"><Settings size={18} />Settings</button><button className="nav-item"><CircleHelp size={18} />Help center</button><div className="profile"><div className="profile-avatar">{userEmail.slice(0,1).toUpperCase()}</div><div className="profile-info"><strong>{userEmail.split("@")[0]}</strong><small>{userEmail}</small></div><button onClick={signOut} title="Sign out"><LogOut size={17} /></button></div></div>
      </aside>
      {mobileOpen && <button className="scrim" onClick={() => setMobileOpen(false)} aria-label="Close menu" />}
      <section className="main-area">
        <header className="topbar"><button className="menu-btn" onClick={() => setMobileOpen(true)}><Menu /></button><div className="breadcrumb">Workspace <span>/</span> {active}</div><div className="top-actions"><span className="status-dot" /> All systems normal <button className="help-icon"><CircleHelp size={18} /></button></div></header>
        <div className="content">
          <div className="welcome-row"><div><div className="eyebrow">SATURDAY, NOVEMBER 14, 2026</div><h1>{active === "Overview" ? "Good morning." : active}</h1><p className="muted">Here’s what’s happening across your business today.</p></div><button className="outline-btn"><Sparkles size={16} /> AI insights <span className="soon-tag">COMING SOON</span></button></div>
          <div className="metric-grid">
            <div className="metric-card"><div className="metric-top"><span>Total leads</span><Users size={18} /></div><strong>{leads.length}</strong><small><span className="positive"><TrendingUp size={13} /> Live data</span> · your pipeline</small></div>
            <div className="metric-card"><div className="metric-top"><span>Open tasks</span><ClipboardList size={18} /></div><strong>{tasks.length - completed}</strong><small>Across your workspace</small></div>
            <div className="metric-card"><div className="metric-top"><span>Completed tasks</span><CheckCircle2 size={18} /></div><strong>{completed}</strong><small>Great progress</small></div>
            <div className="metric-card accent-card"><div className="metric-top"><span>AI business assistant</span><Bot size={18} /></div><strong>Ready to grow?</strong><small>AI Copilot · coming soon</small></div>
          </div>
          <div className="section-grid">
            <section className="panel"><div className="panel-heading"><div><h2>Lead management</h2><p>Keep every opportunity moving forward.</p></div><span className="panel-icon"><BriefcaseBusiness size={18} /></span></div>
              <form className="inline-form" onSubmit={addLead}><input value={leadName} onChange={e => setLeadName(e.target.value)} placeholder="Lead or contact name" required /><input value={leadCompany} onChange={e => setLeadCompany(e.target.value)} placeholder="Company (optional)" /><button className="add-btn" aria-label="Add lead"><Plus size={18} /></button></form>
              <div className="list-toolbar"><strong>Recent leads</strong><div className="search-box"><Search size={14} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search leads" /></div></div>
              <div className="lead-list">{filteredLeads.length ? filteredLeads.slice(0,6).map(lead => <div className="lead-row" key={lead.id}><div className="lead-avatar">{lead.name.slice(0,1).toUpperCase()}</div><div className="lead-info"><strong>{lead.name}</strong><small>{lead.company || "Individual contact"}</small></div><span className="lead-status">{lead.status}</span><button className="delete-btn" onClick={() => deleteLead(lead.id)} title="Delete lead"><X size={15} /></button></div>) : <div className="empty-state">No leads yet. Add your first contact above.</div>}</div>
            </section>
            <section className="panel"><div className="panel-heading"><div><h2>My tasks</h2><p>Small steps create big momentum.</p></div><span className="panel-icon"><CheckCircle2 size={18} /></span></div>
              <form className="inline-form task-form" onSubmit={addTask}><input value={taskTitle} onChange={e => setTaskTitle(e.target.value)} placeholder="Add a task to your list…" required /><button className="add-btn" aria-label="Add task"><Plus size={18} /></button></form>
              <div className="task-list">{tasks.length ? tasks.slice(0,8).map(task => <button className={`task-row ${task.completed ? "done" : ""}`} key={task.id} onClick={() => toggleTask(task)}><span className="task-check">{task.completed && <Check size={13} />}</span><span>{task.title}</span></button>) : <div className="empty-state">Your task list is clear. Add a task to get started.</div>}</div>
              <div className="task-summary"><span>{completed} of {tasks.length} completed</span><div className="progress"><i style={{ width: `${tasks.length ? completed / tasks.length * 100 : 0}%` }} /></div></div>
            </section>
          </div>
          <section className="roadmap-panel"><div><div className="eyebrow">BUILT TO SCALE</div><h2>Your business, connected.</h2><p>More intelligent tools are on the roadmap. This starter currently includes account access, lead management and tasks.</p></div><div className="roadmap-pills"><span><Bot size={15} /> AI Copilot</span><span><Mail size={15} /> Marketing automation</span><span><Activity size={15} /> Advanced analytics</span></div></section>
          {message && <div className="message">{message}</div>}
          <footer>© 2026 BIZNOBIX <span>One Platform. Smarter Business.</span></footer>
        </div>
      </section>
    </main>
  );
}
