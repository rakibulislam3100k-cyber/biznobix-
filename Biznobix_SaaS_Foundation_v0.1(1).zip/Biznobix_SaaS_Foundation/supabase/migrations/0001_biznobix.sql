-- BIZNOBIX starter schema. Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'My Workspace',
  created_at timestamptz not null default now()
);

create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'owner' check (role in ('owner','admin','member')),
  created_at timestamptz not null default now(),
  unique(user_id),
  unique(org_id, user_id)
);

create or replace function public.current_org_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select org_id from public.memberships where user_id = auth.uid() limit 1;
$$;

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null default public.current_org_id() references public.organizations(id) on delete cascade,
  name text not null,
  company text,
  email text,
  status text not null default 'New',
  created_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null default public.current_org_id() references public.organizations(id) on delete cascade,
  title text not null,
  completed boolean not null default false,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare new_org uuid;
begin
  insert into public.organizations(name) values ('My Workspace') returning id into new_org;
  insert into public.memberships(org_id, user_id, role) values (new_org, new.id, 'owner');
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.organizations enable row level security;
alter table public.memberships enable row level security;
alter table public.leads enable row level security;
alter table public.tasks enable row level security;

drop policy if exists "members can view own organization" on public.organizations;
create policy "members can view own organization" on public.organizations
for select using (id = public.current_org_id());

drop policy if exists "users can view own membership" on public.memberships;
create policy "users can view own membership" on public.memberships
for select using (user_id = auth.uid());

drop policy if exists "members manage own leads" on public.leads;
create policy "members manage own leads" on public.leads
for all using (org_id = public.current_org_id())
with check (org_id = public.current_org_id());

drop policy if exists "members manage own tasks" on public.tasks;
create policy "members manage own tasks" on public.tasks
for all using (org_id = public.current_org_id())
with check (org_id = public.current_org_id());

grant usage on schema public to authenticated;
grant select on public.organizations, public.memberships to authenticated;
grant select, insert, update, delete on public.leads, public.tasks to authenticated;
