# BIZNOBIX — SaaS Foundation v0.1

**One Platform. Smarter Business.**

A starter foundation for an AI-powered business operations platform.

## Included in this starter

- Responsive dashboard UI
- Supabase email/password authentication
- Organization and membership foundation
- CRM lead creation, search and deletion
- Task creation and completion
- Row Level Security policies for organization-scoped data

## Not included yet

AI Copilot, workflow execution, WhatsApp/email sending, marketing automation, advanced analytics, billing/subscriptions, team invitations, audit logs and production hardening are future work. This is a starter foundation, not a finished commercial SaaS.

## Requirements

- Node.js 20 or newer
- A Supabase project

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env.local` and add your Supabase Project URL and anon/publishable key:

   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY
   ```

3. In Supabase, open **SQL Editor**, paste and run `supabase/migrations/0001_biznobix.sql`.

4. Start the app:

   ```bash
   npm run dev
   ```

5. Open http://localhost:3000

## Deploy

Import this repository into a hosting provider such as Vercel and add the same two public Supabase environment variables in the project settings. Configure your production site URL in Supabase Authentication URL settings.

## Security notes

- Never put a Supabase `service_role` secret in browser/client code.
- This project has not been security audited or load tested.
- Review and test database policies before production use.
- Enable appropriate email confirmation and password policies in Supabase.
